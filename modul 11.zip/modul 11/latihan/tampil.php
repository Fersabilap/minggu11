<?php
include 'database.php';
$mysqli = new Databases();

?>

<head>
<link href="css/a.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<br><br>
<center><h2>Table Data inputan</h2></center>
<br><br><br><center><a href="index.php" type="submit" name="simpan" class="button"> Tambah </a></center><br><br>
<center>
<table class="table">
    <thead>
        <tr>
            <th>NO</th>
            <th>NAMA</th>
            <th>ALAMAT</th>
            <th>FOTO</th>
            <th>AKSI</th>
        </tr>
    </thead>
    <tbody>
        <?php $no = 1; ?>
        <?php foreach ($mysqli->tampilkan() as $tampils) : ?>
            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $tampils['nama'] ?></td>
                <td><?php echo $tampils['alamat'] ?></td>
                <td>
                    <img src="assets/logo/<?php echo $tampils['logo']; ?>"  width="100"></td>
                <td>
                    <a href="pdf.php?id=<?php echo $tampils['id']; ?>" target="_blank"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF 	|</a>
                    <a href="cetak.php?id=<?php echo $tampils['id']; ?>"><i class="fa fa-download" aria-hidden="true"></i> Unduh	 |</a>
                    <a href="edit.php?id=<?php echo $tampils['id']; ?>&aksi=update"><i class="fa fa-pencil"></i> EDIT 	|</a>
                    <a href="proses.php?id=<?php echo $tampils['id']; ?>&aksi=hapus"><i class="fa fa-trash-o" aria-hidden="true"></i> Del	</a>

                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</center>
